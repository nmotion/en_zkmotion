update firmware method
1. Press the green button before poweron zkmotion(nearby C axis marking have a  hole   )
2. install lpc_driver_installer.exe  lpc VCOM driver
3.power on zkmotion, and then run 'nmotion*axis-update.bat'to update.