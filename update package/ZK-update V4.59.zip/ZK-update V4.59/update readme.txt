update firmware method
1. Press the green button before poweron zkmotion
2. install lpc_driver_installer.exe  lpc VCOM driver
3.power on zkmotion, and then run 'nmotion*axis-update.bat'to update.